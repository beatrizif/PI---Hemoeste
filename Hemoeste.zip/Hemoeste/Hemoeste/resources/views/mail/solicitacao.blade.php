<h1>Sua solicitação foi registrada, {{ $donation->nome }}</h1>
<p>
    Obrigado por fazer parte daquelas poucas pessoas que se empenham na campanha de doação de sangue. Você faz a diferença e salva vidas.
</p>
<p>
    A solicitação está prevista para: {{ $donation->data }} às {{  $donation->hora }}
</p>
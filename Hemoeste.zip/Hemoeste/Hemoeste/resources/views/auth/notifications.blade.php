<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            font-family: Arial, Helvetica, sans-serif;
            background-color: #710C04;
            color: #d3d3d3;
            margin: 0px;
            padding: 0px;
            border: 0px;
        }
        .head{
            background-color: #d3d3d3;
        }
        .img-read{
            padding: 10px;
            height: 100px;
        }
        body{
            font-family: Arial, Helvetica, sans-serif;
            background-color: #710C04;
            color: #d3d3d3;
            margin: 0px;
            padding: 0px;
            border: 0px;
        }
        button{
            background-color: #710C04;
            font-weight: bold;
            color: #d3d3d3;
            height: 30px;
            border: solid 1px #710C04;
            border-radius: 7px;
            margin: 7px;
        }
        .box{
            font-weight: bold;
            display: block;
            background-color: #d3d3d3;
            color: #710C04;
            border: 50px;
            height: 250px;
            width: 300px;
            border-radius: 14px;
            padding: 15px;
            margin: 50px;
        }
    </style>
</head>
<body>
    <center><div class="head">
        <img class="img-read" src="{{asset('img-resource/hemoeste.png')}}">
    </div>
    <div class="box">
        <ul>            
            @forelse (Auth::user()->notifications as $notification)
                @if ($notification->type == 'App\Notifications\UpdateProfileNotification')
                    <li>Você mudou seu nome de {{ $notification->data['old_name'] }} para {{ $notification->data['new_name'] }}</li>
                    <hr>
                @endif
                @if ($notification->type == 'App\Notifications\NewDonationNotification')
                    <li>{{ $notification->data['name'] }} fez uma doação em {{ $notification->data['date'] }}</li>
                    <hr>
                @endif
            @empty
                <h2>Você não possui nenhuma notificação</h2>
            @endforelse
        </ul>
    </div>
    </form></center>
</body>
</html>
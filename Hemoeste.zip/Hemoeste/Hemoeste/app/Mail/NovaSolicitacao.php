<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\{
    Content, Envelope, Address
};
use Illuminate\Queue\SerializesModels;
use App\Models\Doacao;

/**
 * É enviada quando uma nova solicitação de doação é feita
 */
class NovaSolicitacao extends Mailable
{
    use Queueable, SerializesModels;

    private Doacao $doacao;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Doacao $doacao)
    {
        $this->doacao = $doacao;
    }

    /**
     * Get the message envelope.
     *
     * @return \Illuminate\Mail\Mailables\Envelope
     */
    public function envelope()
    {
        return new Envelope(
            from: new Address(env('MAIL_USERNAME')),
            subject: 'Nova Solicitação'
        );
    }

    /**
     * Get the message content definition.
     *
     * @return \Illuminate\Mail\Mailables\Content
     */
    public function content()
    {
        return new Content(
            view: 'mail.solicitacao',
            with: [
                'donation' => $this->doacao,
            ]
        );
    }

    /**
     * Get the attachments for the message.
     *
     * @return array
     */
    public function attachments()
    {
        return [];
    }
}

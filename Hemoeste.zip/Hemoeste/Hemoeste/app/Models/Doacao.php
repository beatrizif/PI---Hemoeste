<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Doacao;
use App\Http\Controllers\DoaController;

class Doacao extends Model
{
    use HasFactory;

    protected $fillable = [
        'nome',
        'data',
        'hora',
        // 'user_id',
    ];
}

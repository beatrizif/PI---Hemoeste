# TaskList

Simple exemple of some MVC/Laravel concepts


## Aula
- Objetivo da aula: mostrar os principais recursos referentes ao uso de rotas
    - Route::get / Route::post
    - Request
    - view()
    - resources
    - vite
    - route:list

- Exemplo: o exemplo consiste em definir as rotas para as seguintes páginas que a aplicação inicialmente deverá ter:
    - LandingPage
    - HomePage/Dashboard
    - Login
    - Register

## Paleta de Cores

Cores usadas na composição da página

 - #264653
 - #2a9d8f
 - #e9c46a
 - #f4a261
 - #e76f51
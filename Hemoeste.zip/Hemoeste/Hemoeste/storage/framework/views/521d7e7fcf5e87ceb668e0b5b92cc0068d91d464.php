<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <center><div class="head">
        <img class="img-read" src="<?php echo e(asset('img-resource/hemoeste.png')); ?>">
    </div>
    <div class="box">
        <h1>Central do Doador</h1>

        <form action="<?php echo e(url('/ver')); ?>" method="GET">
            <button>Ver perfil</button>
        </form>

        <form action="<?php echo e(url('/doacao')); ?>" method="GET">
            <button>Solicitar Doação</button>
        </form>

        <form action="<?php echo e(url('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button>Sair</button>
        </form>
        <form action="<?php echo e(url('/notifications')); ?>" method="GET">
            <button>Notificações</button>
        </form>
    </div>
    </center>
</body>
<style>
    body{
        font-family: Arial, Helvetica, sans-serif;
        background-color: #710C04;
        color: #d3d3d3;
        margin: 0px;
        padding: 0px;
        border: 0px;
    }
    .head{
        background-color: #d3d3d3;
    }
    .img-read{
        padding: 10px;
        height: 100px;
    }
    body{
        font-family: Arial, Helvetica, sans-serif;
        background-color: #710C04;
        color: #d3d3d3;
        margin: 0px;
        padding: 0px;
        border: 0px;
    }
    button{
        background-color: #710C04;
        font-weight: bold;
        color: #d3d3d3;
        height: 30px;
        border: solid 1px #710C04;
        border-radius: 7px;
        margin: 7px;
    }
    .box{
        font-weight: bold;
        display: block;
        background-color: #d3d3d3;
        color: #710C04;
        border: 50px;
        height: 250px;
        width: 300px;
        border-radius: 14px;
        padding: 15px;
        margin: 50px;
    }
</style>
</html><?php /**PATH D:\Dev\Atividades\Hemoeste\resources\views/doador/centraldoDoador.blade.php ENDPATH**/ ?>
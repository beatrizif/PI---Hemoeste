<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hemoeste</title>
</head>
<body>
    <h1>Agora você pode acessar o Portal do Hemoeste na sua casa</h1>

    <form action= "<?php echo e(url('/login')); ?>">
        <button>Central do doador</button>
    </form>
</body>
</html><?php /**PATH C:\Users\Empresa\Downloads\Hemoeste\resources\views/welcome.blade.php ENDPATH**/ ?>
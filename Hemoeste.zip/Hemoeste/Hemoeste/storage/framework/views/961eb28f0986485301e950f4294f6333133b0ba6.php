<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doação</title>
</head>
<body>
    <center><div class="head">
        <img class="img-read" src="<?php echo e(asset('img-resource/hemoeste.png')); ?>">
    </div>
    <div class="box">
    <h1>Registrar doação</h1>
    <form action="<?php echo e(url('/doacao')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="inputs">
            <label for="">Nome do usuário</label>
            <input type="text" id="nome" name="nome">
        </div>

        <div class="inputs">
        <label for="">Data</label>
        <input type="text" id="data" name="data" placeholder="DD/MM/AAAA">
        </div>

        <div class="inputs">
        <label for="">Hora</label>
        <input type="text" id="hora" name="hora" placeholder="XX:XXh">
        </div>
        
        <button>Solicitar</button>
    </form>
    </div><center>
</body>
<style>
    body{
        font-family: Arial, Helvetica, sans-serif;
        background-color: #710C04;
        color: #d3d3d3;
        margin: 0px;
        padding: 0px;
        border: 0px;
    }
    .head{
        background-color: #d3d3d3;
    }
    .img-read{
        padding: 10px;
        height: 100px;
    }
    button{
        background-color: #710C04;
        font-weight: bold;
        color: #d3d3d3;
        height: 30px;
        border: solid 1px #710C04;
        border-radius: 7px;
        margin: 15px;
    }
    .box{
        font-weight: bold;
        display: block;
        background-color: #d3d3d3;
        color: #710C04;
        border: 50px;
        height: 300px;
        width: 350px;
        border-radius: 14px;
        padding: 15px;
        margin: 50px;
    }
    .inputs{
	    border-radius: 10px;
        display: block;
        margin: 15px;
    }
</style>
</html><?php /**PATH D:\Dev\Atividades\Hemoeste\resources\views/doador/doacao.blade.php ENDPATH**/ ?>
<?php echo e($slot); ?>

<?php /**PATH D:\Dev\Atividades\Hemoeste\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>
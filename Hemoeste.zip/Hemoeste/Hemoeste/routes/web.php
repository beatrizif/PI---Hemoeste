<?php

use Illuminate\Support\Facades\Route;
use App\Notifications\UpdateProfileNotification;
use App\Http\Controllers\TaskController;
use App\Http\Controllers\DoaController;
use Illuminate\Http\Request;
use App\Models\Doacao;
use App\Models\User;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
})->middleware(['guest']);

Route::get('/central', function () {
    return view('doador.centraldoDoador');
})->middleware(['auth']);

Route::get('/doacao', [DoaController::class, 'create'])->middleware(['auth']);

Route::post('/doacao', [DoaController::class, 'store'])->middleware(['auth']);

Route::get('/editar', function () {
    return view('doador.editar', [
        'users' => Auth::user(),
    ]);
})->middleware(['auth']);

Route::put('/editar/{id}', function (Request $request, $id) {

    $user = User::find($id);

    $oldName = $user->name;

    $user->name = $request->name;

    $user->save();

    $user->notify(new UpdateProfileNotification($user, $oldName));

    return redirect('/central');

})->middleware(['auth']);

Route::get('/notifications', function () { return view('auth.notifications'); })->middleware(['auth']);

Route::get('/ver', function () {

    $users = User::all();
    
    return view('doador.ver', [
        'users' => $users, ]);
});

require __DIR__ . '/auth.php';



